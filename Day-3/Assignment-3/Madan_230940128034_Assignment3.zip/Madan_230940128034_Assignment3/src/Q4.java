import com.cdac.pack1.Student;
import com.cdac.pack2.Batch;

public class Q4 {
	public static void main(String[] args) 
	{
		Student s1=new Student(101,"Dhoni");
		Batch s2=new Batch();
		
		s1.display();
		s2.display();
	}
}
